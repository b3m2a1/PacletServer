{
  <|
    "href"->"https://mathematica.stackexchange.com",
    "body"->"StackExchange"
    |>
  }

{
  <|
    "href"->"pages/about.html",
    "body"->"About"
    |>,
  <|
    "href"->"pages/toc.html",
    "body"->"Table Of Contents"
    |>,
  <|
    "href"->"categories.html",
    "body"->"Categories"
    |>,
  <|
    "href"->"tags.html",
    "body"->"Tags"
    |>
  }

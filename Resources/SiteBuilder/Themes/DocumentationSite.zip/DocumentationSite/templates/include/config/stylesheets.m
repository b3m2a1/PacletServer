{
  "bootstrap.css",
  "font-awesome.css",
  "https://fonts.googleapis.com/css?family=Source+Code+Pro",
  "https://reference.wolfram.com/language-assets/css/special-styles.css",
  "common.css",
  "style.css"
  }
